--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE fil_rouge;
--
-- Name: fil_rouge; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE fil_rouge WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'French_France.1252';


ALTER DATABASE fil_rouge OWNER TO postgres;

\connect fil_rouge

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: ludorecherche_addon_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_addon_artists (
    id integer NOT NULL,
    addon_id integer NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_addon_artists OWNER TO postgres;

--
-- Name: ludorecherche_add_on_artists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_add_on_artists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_add_on_artists_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_add_on_artists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_add_on_artists_id_seq OWNED BY public.ludorecherche_addon_artists.id;


--
-- Name: ludorecherche_addon_designers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_addon_designers (
    id integer NOT NULL,
    addon_id integer NOT NULL,
    designer_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_addon_designers OWNER TO postgres;

--
-- Name: ludorecherche_add_on_designers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_add_on_designers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_add_on_designers_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_add_on_designers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_add_on_designers_id_seq OWNED BY public.ludorecherche_addon_designers.id;


--
-- Name: ludorecherche_addon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_addon (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    player_min integer,
    player_max integer,
    playing_time character varying(50),
    difficulty_id integer,
    created_at timestamp with time zone NOT NULL,
    picture text NOT NULL,
    bgg_link text NOT NULL,
    game_id integer,
    language_id integer,
    age integer
);


ALTER TABLE public.ludorecherche_addon OWNER TO postgres;

--
-- Name: ludorecherche_add_on_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_add_on_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_add_on_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_add_on_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_add_on_id_seq OWNED BY public.ludorecherche_addon.id;


--
-- Name: ludorecherche_addon_playing_mode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_addon_playing_mode (
    id integer NOT NULL,
    addon_id integer NOT NULL,
    playingmode_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_addon_playing_mode OWNER TO postgres;

--
-- Name: ludorecherche_add_on_playing_mode_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_add_on_playing_mode_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_add_on_playing_mode_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_add_on_playing_mode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_add_on_playing_mode_id_seq OWNED BY public.ludorecherche_addon_playing_mode.id;


--
-- Name: ludorecherche_addon_publishers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_addon_publishers (
    id integer NOT NULL,
    addon_id integer NOT NULL,
    publisher_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_addon_publishers OWNER TO postgres;

--
-- Name: ludorecherche_add_on_publishers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_add_on_publishers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_add_on_publishers_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_add_on_publishers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_add_on_publishers_id_seq OWNED BY public.ludorecherche_addon_publishers.id;


--
-- Name: ludorecherche_artist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_artist (
    id integer NOT NULL,
    name character varying(200) NOT NULL
);


ALTER TABLE public.ludorecherche_artist OWNER TO postgres;

--
-- Name: ludorecherche_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_artist_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_artist_id_seq OWNED BY public.ludorecherche_artist.id;


--
-- Name: ludorecherche_designer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_designer (
    id integer NOT NULL,
    name character varying(200) NOT NULL
);


ALTER TABLE public.ludorecherche_designer OWNER TO postgres;

--
-- Name: ludorecherche_designer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_designer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_designer_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_designer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_designer_id_seq OWNED BY public.ludorecherche_designer.id;


--
-- Name: ludorecherche_difficulty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_difficulty (
    id integer NOT NULL,
    name character varying(200) NOT NULL
);


ALTER TABLE public.ludorecherche_difficulty OWNER TO postgres;

--
-- Name: ludorecherche_difficulty_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_difficulty_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_difficulty_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_difficulty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_difficulty_id_seq OWNED BY public.ludorecherche_difficulty.id;


--
-- Name: ludorecherche_game; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_game (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    player_min integer,
    player_max integer,
    playing_time character varying(50),
    difficulty_id integer,
    created_at timestamp with time zone NOT NULL,
    picture text NOT NULL,
    bgg_link text NOT NULL,
    by_player boolean NOT NULL,
    max_time integer,
    age integer,
    language_id integer
);


ALTER TABLE public.ludorecherche_game OWNER TO postgres;

--
-- Name: ludorecherche_game_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_game_artists (
    id integer NOT NULL,
    game_id integer NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_game_artists OWNER TO postgres;

--
-- Name: ludorecherche_game_artists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_game_artists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_game_artists_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_game_artists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_game_artists_id_seq OWNED BY public.ludorecherche_game_artists.id;


--
-- Name: ludorecherche_game_designers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_game_designers (
    id integer NOT NULL,
    game_id integer NOT NULL,
    designer_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_game_designers OWNER TO postgres;

--
-- Name: ludorecherche_game_designers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_game_designers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_game_designers_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_game_designers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_game_designers_id_seq OWNED BY public.ludorecherche_game_designers.id;


--
-- Name: ludorecherche_game_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_game_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_game_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_game_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_game_id_seq OWNED BY public.ludorecherche_game.id;


--
-- Name: ludorecherche_game_playing_mode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_game_playing_mode (
    id integer NOT NULL,
    game_id integer NOT NULL,
    playingmode_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_game_playing_mode OWNER TO postgres;

--
-- Name: ludorecherche_game_playing_mode_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_game_playing_mode_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_game_playing_mode_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_game_playing_mode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_game_playing_mode_id_seq OWNED BY public.ludorecherche_game_playing_mode.id;


--
-- Name: ludorecherche_game_publishers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_game_publishers (
    id integer NOT NULL,
    game_id integer NOT NULL,
    publisher_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_game_publishers OWNER TO postgres;

--
-- Name: ludorecherche_game_publishers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_game_publishers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_game_publishers_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_game_publishers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_game_publishers_id_seq OWNED BY public.ludorecherche_game_publishers.id;


--
-- Name: ludorecherche_game_tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_game_tag (
    id integer NOT NULL,
    game_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_game_tag OWNER TO postgres;

--
-- Name: ludorecherche_game_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_game_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_game_tag_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_game_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_game_tag_id_seq OWNED BY public.ludorecherche_game_tag.id;


--
-- Name: ludorecherche_language; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_language (
    id integer NOT NULL,
    name character varying(200) NOT NULL
);


ALTER TABLE public.ludorecherche_language OWNER TO postgres;

--
-- Name: ludorecherche_language_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_language_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_language_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_language_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_language_id_seq OWNED BY public.ludorecherche_language.id;


--
-- Name: ludorecherche_multiaddon_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_multiaddon_artists (
    id integer NOT NULL,
    multiaddon_id integer NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_multiaddon_artists OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_artists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_multi_add_on_artists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_multi_add_on_artists_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_artists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_multi_add_on_artists_id_seq OWNED BY public.ludorecherche_multiaddon_artists.id;


--
-- Name: ludorecherche_multiaddon_designers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_multiaddon_designers (
    id integer NOT NULL,
    multiaddon_id integer NOT NULL,
    designer_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_multiaddon_designers OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_designers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_multi_add_on_designers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_multi_add_on_designers_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_designers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_multi_add_on_designers_id_seq OWNED BY public.ludorecherche_multiaddon_designers.id;


--
-- Name: ludorecherche_multiaddon_games; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_multiaddon_games (
    id integer NOT NULL,
    multiaddon_id integer NOT NULL,
    game_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_multiaddon_games OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_games_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_multi_add_on_games_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_multi_add_on_games_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_games_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_multi_add_on_games_id_seq OWNED BY public.ludorecherche_multiaddon_games.id;


--
-- Name: ludorecherche_multiaddon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_multiaddon (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    player_min integer,
    player_max integer,
    playing_time character varying(50),
    created_at timestamp with time zone NOT NULL,
    picture text NOT NULL,
    bgg_link text NOT NULL,
    difficulty_id integer,
    language_id integer,
    age integer
);


ALTER TABLE public.ludorecherche_multiaddon OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_multi_add_on_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_multi_add_on_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_multi_add_on_id_seq OWNED BY public.ludorecherche_multiaddon.id;


--
-- Name: ludorecherche_multiaddon_playing_mode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_multiaddon_playing_mode (
    id integer NOT NULL,
    multiaddon_id integer NOT NULL,
    playingmode_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_multiaddon_playing_mode OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_playing_mode_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_multi_add_on_playing_mode_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_multi_add_on_playing_mode_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_playing_mode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_multi_add_on_playing_mode_id_seq OWNED BY public.ludorecherche_multiaddon_playing_mode.id;


--
-- Name: ludorecherche_multiaddon_publishers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_multiaddon_publishers (
    id integer NOT NULL,
    multiaddon_id integer NOT NULL,
    publisher_id integer NOT NULL
);


ALTER TABLE public.ludorecherche_multiaddon_publishers OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_publishers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_multi_add_on_publishers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_multi_add_on_publishers_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_multi_add_on_publishers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_multi_add_on_publishers_id_seq OWNED BY public.ludorecherche_multiaddon_publishers.id;


--
-- Name: ludorecherche_playingmode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_playingmode (
    id integer NOT NULL,
    name character varying(200) NOT NULL
);


ALTER TABLE public.ludorecherche_playingmode OWNER TO postgres;

--
-- Name: ludorecherche_playingmode_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_playingmode_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_playingmode_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_playingmode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_playingmode_id_seq OWNED BY public.ludorecherche_playingmode.id;


--
-- Name: ludorecherche_publisher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_publisher (
    id integer NOT NULL,
    name character varying(200) NOT NULL
);


ALTER TABLE public.ludorecherche_publisher OWNER TO postgres;

--
-- Name: ludorecherche_publisher_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_publisher_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_publisher_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_publisher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_publisher_id_seq OWNED BY public.ludorecherche_publisher.id;


--
-- Name: ludorecherche_tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ludorecherche_tag (
    id integer NOT NULL,
    name character varying(200) NOT NULL
);


ALTER TABLE public.ludorecherche_tag OWNER TO postgres;

--
-- Name: ludorecherche_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ludorecherche_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ludorecherche_tag_id_seq OWNER TO postgres;

--
-- Name: ludorecherche_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ludorecherche_tag_id_seq OWNED BY public.ludorecherche_tag.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: ludorecherche_addon id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_add_on_id_seq'::regclass);


--
-- Name: ludorecherche_addon_artists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_artists ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_add_on_artists_id_seq'::regclass);


--
-- Name: ludorecherche_addon_designers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_designers ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_add_on_designers_id_seq'::regclass);


--
-- Name: ludorecherche_addon_playing_mode id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_playing_mode ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_add_on_playing_mode_id_seq'::regclass);


--
-- Name: ludorecherche_addon_publishers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_publishers ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_add_on_publishers_id_seq'::regclass);


--
-- Name: ludorecherche_artist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_artist ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_artist_id_seq'::regclass);


--
-- Name: ludorecherche_designer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_designer ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_designer_id_seq'::regclass);


--
-- Name: ludorecherche_difficulty id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_difficulty ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_difficulty_id_seq'::regclass);


--
-- Name: ludorecherche_game id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_game_id_seq'::regclass);


--
-- Name: ludorecherche_game_artists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_artists ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_game_artists_id_seq'::regclass);


--
-- Name: ludorecherche_game_designers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_designers ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_game_designers_id_seq'::regclass);


--
-- Name: ludorecherche_game_playing_mode id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_playing_mode ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_game_playing_mode_id_seq'::regclass);


--
-- Name: ludorecherche_game_publishers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_publishers ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_game_publishers_id_seq'::regclass);


--
-- Name: ludorecherche_game_tag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_tag ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_game_tag_id_seq'::regclass);


--
-- Name: ludorecherche_language id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_language ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_language_id_seq'::regclass);


--
-- Name: ludorecherche_multiaddon id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_multi_add_on_id_seq'::regclass);


--
-- Name: ludorecherche_multiaddon_artists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_artists ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_multi_add_on_artists_id_seq'::regclass);


--
-- Name: ludorecherche_multiaddon_designers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_designers ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_multi_add_on_designers_id_seq'::regclass);


--
-- Name: ludorecherche_multiaddon_games id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_games ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_multi_add_on_games_id_seq'::regclass);


--
-- Name: ludorecherche_multiaddon_playing_mode id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_playing_mode ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_multi_add_on_playing_mode_id_seq'::regclass);


--
-- Name: ludorecherche_multiaddon_publishers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_publishers ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_multi_add_on_publishers_id_seq'::regclass);


--
-- Name: ludorecherche_playingmode id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_playingmode ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_playingmode_id_seq'::regclass);


--
-- Name: ludorecherche_publisher id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_publisher ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_publisher_id_seq'::regclass);


--
-- Name: ludorecherche_tag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_tag ALTER COLUMN id SET DEFAULT nextval('public.ludorecherche_tag_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3454.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3456.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3452.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/3458.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/3460.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3462.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3464.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3450.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3497.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3465.dat';

--
-- Data for Name: ludorecherche_addon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_addon (id, name, player_min, player_max, playing_time, difficulty_id, created_at, picture, bgg_link, game_id, language_id, age) FROM stdin;
\.
COPY public.ludorecherche_addon (id, name, player_min, player_max, playing_time, difficulty_id, created_at, picture, bgg_link, game_id, language_id, age) FROM '$$PATH$$/3467.dat';

--
-- Data for Name: ludorecherche_addon_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_addon_artists (id, addon_id, artist_id) FROM stdin;
\.
COPY public.ludorecherche_addon_artists (id, addon_id, artist_id) FROM '$$PATH$$/3483.dat';

--
-- Data for Name: ludorecherche_addon_designers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_addon_designers (id, addon_id, designer_id) FROM stdin;
\.
COPY public.ludorecherche_addon_designers (id, addon_id, designer_id) FROM '$$PATH$$/3485.dat';

--
-- Data for Name: ludorecherche_addon_playing_mode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_addon_playing_mode (id, addon_id, playingmode_id) FROM stdin;
\.
COPY public.ludorecherche_addon_playing_mode (id, addon_id, playingmode_id) FROM '$$PATH$$/3493.dat';

--
-- Data for Name: ludorecherche_addon_publishers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_addon_publishers (id, addon_id, publisher_id) FROM stdin;
\.
COPY public.ludorecherche_addon_publishers (id, addon_id, publisher_id) FROM '$$PATH$$/3487.dat';

--
-- Data for Name: ludorecherche_artist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_artist (id, name) FROM stdin;
\.
COPY public.ludorecherche_artist (id, name) FROM '$$PATH$$/3469.dat';

--
-- Data for Name: ludorecherche_designer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_designer (id, name) FROM stdin;
\.
COPY public.ludorecherche_designer (id, name) FROM '$$PATH$$/3471.dat';

--
-- Data for Name: ludorecherche_difficulty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_difficulty (id, name) FROM stdin;
\.
COPY public.ludorecherche_difficulty (id, name) FROM '$$PATH$$/3499.dat';

--
-- Data for Name: ludorecherche_game; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_game (id, name, player_min, player_max, playing_time, difficulty_id, created_at, picture, bgg_link, by_player, max_time, age, language_id) FROM stdin;
\.
COPY public.ludorecherche_game (id, name, player_min, player_max, playing_time, difficulty_id, created_at, picture, bgg_link, by_player, max_time, age, language_id) FROM '$$PATH$$/3475.dat';

--
-- Data for Name: ludorecherche_game_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_game_artists (id, game_id, artist_id) FROM stdin;
\.
COPY public.ludorecherche_game_artists (id, game_id, artist_id) FROM '$$PATH$$/3477.dat';

--
-- Data for Name: ludorecherche_game_designers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_game_designers (id, game_id, designer_id) FROM stdin;
\.
COPY public.ludorecherche_game_designers (id, game_id, designer_id) FROM '$$PATH$$/3479.dat';

--
-- Data for Name: ludorecherche_game_playing_mode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_game_playing_mode (id, game_id, playingmode_id) FROM stdin;
\.
COPY public.ludorecherche_game_playing_mode (id, game_id, playingmode_id) FROM '$$PATH$$/3495.dat';

--
-- Data for Name: ludorecherche_game_publishers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_game_publishers (id, game_id, publisher_id) FROM stdin;
\.
COPY public.ludorecherche_game_publishers (id, game_id, publisher_id) FROM '$$PATH$$/3481.dat';

--
-- Data for Name: ludorecherche_game_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_game_tag (id, game_id, tag_id) FROM stdin;
\.
COPY public.ludorecherche_game_tag (id, game_id, tag_id) FROM '$$PATH$$/3503.dat';

--
-- Data for Name: ludorecherche_language; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_language (id, name) FROM stdin;
\.
COPY public.ludorecherche_language (id, name) FROM '$$PATH$$/3489.dat';

--
-- Data for Name: ludorecherche_multiaddon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_multiaddon (id, name, player_min, player_max, playing_time, created_at, picture, bgg_link, difficulty_id, language_id, age) FROM stdin;
\.
COPY public.ludorecherche_multiaddon (id, name, player_min, player_max, playing_time, created_at, picture, bgg_link, difficulty_id, language_id, age) FROM '$$PATH$$/3505.dat';

--
-- Data for Name: ludorecherche_multiaddon_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_multiaddon_artists (id, multiaddon_id, artist_id) FROM stdin;
\.
COPY public.ludorecherche_multiaddon_artists (id, multiaddon_id, artist_id) FROM '$$PATH$$/3507.dat';

--
-- Data for Name: ludorecherche_multiaddon_designers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_multiaddon_designers (id, multiaddon_id, designer_id) FROM stdin;
\.
COPY public.ludorecherche_multiaddon_designers (id, multiaddon_id, designer_id) FROM '$$PATH$$/3509.dat';

--
-- Data for Name: ludorecherche_multiaddon_games; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_multiaddon_games (id, multiaddon_id, game_id) FROM stdin;
\.
COPY public.ludorecherche_multiaddon_games (id, multiaddon_id, game_id) FROM '$$PATH$$/3511.dat';

--
-- Data for Name: ludorecherche_multiaddon_playing_mode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_multiaddon_playing_mode (id, multiaddon_id, playingmode_id) FROM stdin;
\.
COPY public.ludorecherche_multiaddon_playing_mode (id, multiaddon_id, playingmode_id) FROM '$$PATH$$/3513.dat';

--
-- Data for Name: ludorecherche_multiaddon_publishers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_multiaddon_publishers (id, multiaddon_id, publisher_id) FROM stdin;
\.
COPY public.ludorecherche_multiaddon_publishers (id, multiaddon_id, publisher_id) FROM '$$PATH$$/3515.dat';

--
-- Data for Name: ludorecherche_playingmode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_playingmode (id, name) FROM stdin;
\.
COPY public.ludorecherche_playingmode (id, name) FROM '$$PATH$$/3491.dat';

--
-- Data for Name: ludorecherche_publisher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_publisher (id, name) FROM stdin;
\.
COPY public.ludorecherche_publisher (id, name) FROM '$$PATH$$/3473.dat';

--
-- Data for Name: ludorecherche_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ludorecherche_tag (id, name) FROM stdin;
\.
COPY public.ludorecherche_tag (id, name) FROM '$$PATH$$/3501.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 76, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 480, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 17, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 42, true);


--
-- Name: ludorecherche_add_on_artists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_add_on_artists_id_seq', 27, true);


--
-- Name: ludorecherche_add_on_designers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_add_on_designers_id_seq', 43, true);


--
-- Name: ludorecherche_add_on_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_add_on_id_seq', 18, true);


--
-- Name: ludorecherche_add_on_playing_mode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_add_on_playing_mode_id_seq', 24, true);


--
-- Name: ludorecherche_add_on_publishers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_add_on_publishers_id_seq', 24, true);


--
-- Name: ludorecherche_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_artist_id_seq', 92, true);


--
-- Name: ludorecherche_designer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_designer_id_seq', 101, true);


--
-- Name: ludorecherche_difficulty_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_difficulty_id_seq', 3, true);


--
-- Name: ludorecherche_game_artists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_game_artists_id_seq', 109, true);


--
-- Name: ludorecherche_game_designers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_game_designers_id_seq', 117, true);


--
-- Name: ludorecherche_game_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_game_id_seq', 81, true);


--
-- Name: ludorecherche_game_playing_mode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_game_playing_mode_id_seq', 90, true);


--
-- Name: ludorecherche_game_publishers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_game_publishers_id_seq', 91, true);


--
-- Name: ludorecherche_game_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_game_tag_id_seq', 191, true);


--
-- Name: ludorecherche_language_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_language_id_seq', 2, true);


--
-- Name: ludorecherche_multi_add_on_artists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_multi_add_on_artists_id_seq', 1, true);


--
-- Name: ludorecherche_multi_add_on_designers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_multi_add_on_designers_id_seq', 8, true);


--
-- Name: ludorecherche_multi_add_on_games_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_multi_add_on_games_id_seq', 8, true);


--
-- Name: ludorecherche_multi_add_on_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_multi_add_on_id_seq', 2, true);


--
-- Name: ludorecherche_multi_add_on_playing_mode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_multi_add_on_playing_mode_id_seq', 4, true);


--
-- Name: ludorecherche_multi_add_on_publishers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_multi_add_on_publishers_id_seq', 3, true);


--
-- Name: ludorecherche_playingmode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_playingmode_id_seq', 5, true);


--
-- Name: ludorecherche_publisher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_publisher_id_seq', 51, true);


--
-- Name: ludorecherche_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ludorecherche_tag_id_seq', 49, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: ludorecherche_addon_artists ludorecherche_add_on_artists_add_on_id_artist_id_9db8303a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_artists
    ADD CONSTRAINT ludorecherche_add_on_artists_add_on_id_artist_id_9db8303a_uniq UNIQUE (addon_id, artist_id);


--
-- Name: ludorecherche_addon_artists ludorecherche_add_on_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_artists
    ADD CONSTRAINT ludorecherche_add_on_artists_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_addon_designers ludorecherche_add_on_des_add_on_id_designer_id_33beca4e_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_designers
    ADD CONSTRAINT ludorecherche_add_on_des_add_on_id_designer_id_33beca4e_uniq UNIQUE (addon_id, designer_id);


--
-- Name: ludorecherche_addon_designers ludorecherche_add_on_designers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_designers
    ADD CONSTRAINT ludorecherche_add_on_designers_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_addon ludorecherche_add_on_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon
    ADD CONSTRAINT ludorecherche_add_on_name_key UNIQUE (name);


--
-- Name: ludorecherche_addon ludorecherche_add_on_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon
    ADD CONSTRAINT ludorecherche_add_on_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_addon_playing_mode ludorecherche_add_on_pla_add_on_id_playingmode_id_2ef709e7_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_playing_mode
    ADD CONSTRAINT ludorecherche_add_on_pla_add_on_id_playingmode_id_2ef709e7_uniq UNIQUE (addon_id, playingmode_id);


--
-- Name: ludorecherche_addon_playing_mode ludorecherche_add_on_playing_mode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_playing_mode
    ADD CONSTRAINT ludorecherche_add_on_playing_mode_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_addon_publishers ludorecherche_add_on_pub_add_on_id_publisher_id_e6c5a0b8_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_publishers
    ADD CONSTRAINT ludorecherche_add_on_pub_add_on_id_publisher_id_e6c5a0b8_uniq UNIQUE (addon_id, publisher_id);


--
-- Name: ludorecherche_addon_publishers ludorecherche_add_on_publishers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_publishers
    ADD CONSTRAINT ludorecherche_add_on_publishers_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_artist ludorecherche_artist_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_artist
    ADD CONSTRAINT ludorecherche_artist_name_key UNIQUE (name);


--
-- Name: ludorecherche_artist ludorecherche_artist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_artist
    ADD CONSTRAINT ludorecherche_artist_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_designer ludorecherche_designer_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_designer
    ADD CONSTRAINT ludorecherche_designer_name_key UNIQUE (name);


--
-- Name: ludorecherche_designer ludorecherche_designer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_designer
    ADD CONSTRAINT ludorecherche_designer_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_difficulty ludorecherche_difficulty_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_difficulty
    ADD CONSTRAINT ludorecherche_difficulty_name_key UNIQUE (name);


--
-- Name: ludorecherche_difficulty ludorecherche_difficulty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_difficulty
    ADD CONSTRAINT ludorecherche_difficulty_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_game_artists ludorecherche_game_artists_game_id_artist_id_0c3b929f_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_artists
    ADD CONSTRAINT ludorecherche_game_artists_game_id_artist_id_0c3b929f_uniq UNIQUE (game_id, artist_id);


--
-- Name: ludorecherche_game_artists ludorecherche_game_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_artists
    ADD CONSTRAINT ludorecherche_game_artists_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_game_designers ludorecherche_game_designers_game_id_designer_id_98196acb_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_designers
    ADD CONSTRAINT ludorecherche_game_designers_game_id_designer_id_98196acb_uniq UNIQUE (game_id, designer_id);


--
-- Name: ludorecherche_game_designers ludorecherche_game_designers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_designers
    ADD CONSTRAINT ludorecherche_game_designers_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_game ludorecherche_game_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game
    ADD CONSTRAINT ludorecherche_game_name_key UNIQUE (name);


--
-- Name: ludorecherche_game ludorecherche_game_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game
    ADD CONSTRAINT ludorecherche_game_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_game_playing_mode ludorecherche_game_playi_game_id_playingmode_id_5ab1ddc5_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_playing_mode
    ADD CONSTRAINT ludorecherche_game_playi_game_id_playingmode_id_5ab1ddc5_uniq UNIQUE (game_id, playingmode_id);


--
-- Name: ludorecherche_game_playing_mode ludorecherche_game_playing_mode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_playing_mode
    ADD CONSTRAINT ludorecherche_game_playing_mode_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_game_publishers ludorecherche_game_publi_game_id_publisher_id_d2ab4a93_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_publishers
    ADD CONSTRAINT ludorecherche_game_publi_game_id_publisher_id_d2ab4a93_uniq UNIQUE (game_id, publisher_id);


--
-- Name: ludorecherche_game_publishers ludorecherche_game_publishers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_publishers
    ADD CONSTRAINT ludorecherche_game_publishers_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_game_tag ludorecherche_game_tag_game_id_tag_id_79514770_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_tag
    ADD CONSTRAINT ludorecherche_game_tag_game_id_tag_id_79514770_uniq UNIQUE (game_id, tag_id);


--
-- Name: ludorecherche_game_tag ludorecherche_game_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_tag
    ADD CONSTRAINT ludorecherche_game_tag_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_language ludorecherche_language_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_language
    ADD CONSTRAINT ludorecherche_language_name_key UNIQUE (name);


--
-- Name: ludorecherche_language ludorecherche_language_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_language
    ADD CONSTRAINT ludorecherche_language_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_multiaddon_artists ludorecherche_multi_add__multi_add_on_id_artist_i_607ccaae_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_artists
    ADD CONSTRAINT ludorecherche_multi_add__multi_add_on_id_artist_i_607ccaae_uniq UNIQUE (multiaddon_id, artist_id);


--
-- Name: ludorecherche_multiaddon_designers ludorecherche_multi_add__multi_add_on_id_designer_9d63726f_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_designers
    ADD CONSTRAINT ludorecherche_multi_add__multi_add_on_id_designer_9d63726f_uniq UNIQUE (multiaddon_id, designer_id);


--
-- Name: ludorecherche_multiaddon_games ludorecherche_multi_add__multi_add_on_id_game_id_96b2ba2d_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_games
    ADD CONSTRAINT ludorecherche_multi_add__multi_add_on_id_game_id_96b2ba2d_uniq UNIQUE (multiaddon_id, game_id);


--
-- Name: ludorecherche_multiaddon_playing_mode ludorecherche_multi_add__multi_add_on_id_playingm_03ef07e1_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_playing_mode
    ADD CONSTRAINT ludorecherche_multi_add__multi_add_on_id_playingm_03ef07e1_uniq UNIQUE (multiaddon_id, playingmode_id);


--
-- Name: ludorecherche_multiaddon_publishers ludorecherche_multi_add__multi_add_on_id_publishe_276d40ae_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_publishers
    ADD CONSTRAINT ludorecherche_multi_add__multi_add_on_id_publishe_276d40ae_uniq UNIQUE (multiaddon_id, publisher_id);


--
-- Name: ludorecherche_multiaddon_artists ludorecherche_multi_add_on_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_artists
    ADD CONSTRAINT ludorecherche_multi_add_on_artists_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_multiaddon_designers ludorecherche_multi_add_on_designers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_designers
    ADD CONSTRAINT ludorecherche_multi_add_on_designers_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_multiaddon_games ludorecherche_multi_add_on_games_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_games
    ADD CONSTRAINT ludorecherche_multi_add_on_games_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_multiaddon ludorecherche_multi_add_on_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon
    ADD CONSTRAINT ludorecherche_multi_add_on_name_key UNIQUE (name);


--
-- Name: ludorecherche_multiaddon ludorecherche_multi_add_on_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon
    ADD CONSTRAINT ludorecherche_multi_add_on_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_multiaddon_playing_mode ludorecherche_multi_add_on_playing_mode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_playing_mode
    ADD CONSTRAINT ludorecherche_multi_add_on_playing_mode_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_multiaddon_publishers ludorecherche_multi_add_on_publishers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_publishers
    ADD CONSTRAINT ludorecherche_multi_add_on_publishers_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_playingmode ludorecherche_playingmode_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_playingmode
    ADD CONSTRAINT ludorecherche_playingmode_name_key UNIQUE (name);


--
-- Name: ludorecherche_playingmode ludorecherche_playingmode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_playingmode
    ADD CONSTRAINT ludorecherche_playingmode_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_publisher ludorecherche_publisher_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_publisher
    ADD CONSTRAINT ludorecherche_publisher_name_key UNIQUE (name);


--
-- Name: ludorecherche_publisher ludorecherche_publisher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_publisher
    ADD CONSTRAINT ludorecherche_publisher_pkey PRIMARY KEY (id);


--
-- Name: ludorecherche_tag ludorecherche_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_tag
    ADD CONSTRAINT ludorecherche_tag_name_key UNIQUE (name);


--
-- Name: ludorecherche_tag ludorecherche_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_tag
    ADD CONSTRAINT ludorecherche_tag_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: ludorecherche_add_on_artists_add_on_id_06c1b675; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_artists_add_on_id_06c1b675 ON public.ludorecherche_addon_artists USING btree (addon_id);


--
-- Name: ludorecherche_add_on_artists_artist_id_947142f9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_artists_artist_id_947142f9 ON public.ludorecherche_addon_artists USING btree (artist_id);


--
-- Name: ludorecherche_add_on_designers_add_on_id_91c9524f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_designers_add_on_id_91c9524f ON public.ludorecherche_addon_designers USING btree (addon_id);


--
-- Name: ludorecherche_add_on_designers_designer_id_c16eab7d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_designers_designer_id_c16eab7d ON public.ludorecherche_addon_designers USING btree (designer_id);


--
-- Name: ludorecherche_add_on_difficulty_id_36e9a090; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_difficulty_id_36e9a090 ON public.ludorecherche_addon USING btree (difficulty_id);


--
-- Name: ludorecherche_add_on_game_id_fc9844ac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_game_id_fc9844ac ON public.ludorecherche_addon USING btree (game_id);


--
-- Name: ludorecherche_add_on_language_id_5573aafd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_language_id_5573aafd ON public.ludorecherche_addon USING btree (language_id);


--
-- Name: ludorecherche_add_on_name_d5b13084_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_name_d5b13084_like ON public.ludorecherche_addon USING btree (name varchar_pattern_ops);


--
-- Name: ludorecherche_add_on_playing_mode_add_on_id_ef1f0186; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_playing_mode_add_on_id_ef1f0186 ON public.ludorecherche_addon_playing_mode USING btree (addon_id);


--
-- Name: ludorecherche_add_on_playing_mode_playingmode_id_12919a41; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_playing_mode_playingmode_id_12919a41 ON public.ludorecherche_addon_playing_mode USING btree (playingmode_id);


--
-- Name: ludorecherche_add_on_publishers_add_on_id_9ca3fd40; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_publishers_add_on_id_9ca3fd40 ON public.ludorecherche_addon_publishers USING btree (addon_id);


--
-- Name: ludorecherche_add_on_publishers_publisher_id_14abff3e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_add_on_publishers_publisher_id_14abff3e ON public.ludorecherche_addon_publishers USING btree (publisher_id);


--
-- Name: ludorecherche_artist_name_7c60ea7e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_artist_name_7c60ea7e_like ON public.ludorecherche_artist USING btree (name varchar_pattern_ops);


--
-- Name: ludorecherche_designer_name_36cdcde4_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_designer_name_36cdcde4_like ON public.ludorecherche_designer USING btree (name varchar_pattern_ops);


--
-- Name: ludorecherche_difficulty_name_e59ec408_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_difficulty_name_e59ec408_like ON public.ludorecherche_difficulty USING btree (name varchar_pattern_ops);


--
-- Name: ludorecherche_game_artists_artist_id_3e5506bf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_artists_artist_id_3e5506bf ON public.ludorecherche_game_artists USING btree (artist_id);


--
-- Name: ludorecherche_game_artists_game_id_2ba0fcde; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_artists_game_id_2ba0fcde ON public.ludorecherche_game_artists USING btree (game_id);


--
-- Name: ludorecherche_game_designers_designer_id_8b4d087f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_designers_designer_id_8b4d087f ON public.ludorecherche_game_designers USING btree (designer_id);


--
-- Name: ludorecherche_game_designers_game_id_6d1526cc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_designers_game_id_6d1526cc ON public.ludorecherche_game_designers USING btree (game_id);


--
-- Name: ludorecherche_game_difficulty_id_c4f6b87a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_difficulty_id_c4f6b87a ON public.ludorecherche_game USING btree (difficulty_id);


--
-- Name: ludorecherche_game_language_id_38e7eecd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_language_id_38e7eecd ON public.ludorecherche_game USING btree (language_id);


--
-- Name: ludorecherche_game_name_82b8126a_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_name_82b8126a_like ON public.ludorecherche_game USING btree (name varchar_pattern_ops);


--
-- Name: ludorecherche_game_playing_mode_game_id_62bd95b2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_playing_mode_game_id_62bd95b2 ON public.ludorecherche_game_playing_mode USING btree (game_id);


--
-- Name: ludorecherche_game_playing_mode_playingmode_id_fa02659e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_playing_mode_playingmode_id_fa02659e ON public.ludorecherche_game_playing_mode USING btree (playingmode_id);


--
-- Name: ludorecherche_game_publishers_game_id_a425abf8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_publishers_game_id_a425abf8 ON public.ludorecherche_game_publishers USING btree (game_id);


--
-- Name: ludorecherche_game_publishers_publisher_id_5176fa38; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_publishers_publisher_id_5176fa38 ON public.ludorecherche_game_publishers USING btree (publisher_id);


--
-- Name: ludorecherche_game_tag_game_id_065ca217; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_tag_game_id_065ca217 ON public.ludorecherche_game_tag USING btree (game_id);


--
-- Name: ludorecherche_game_tag_tag_id_d515082c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_game_tag_tag_id_d515082c ON public.ludorecherche_game_tag USING btree (tag_id);


--
-- Name: ludorecherche_language_name_24fe12a7_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_language_name_24fe12a7_like ON public.ludorecherche_language USING btree (name varchar_pattern_ops);


--
-- Name: ludorecherche_multi_add_on_artists_artist_id_b04b65bc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_artists_artist_id_b04b65bc ON public.ludorecherche_multiaddon_artists USING btree (artist_id);


--
-- Name: ludorecherche_multi_add_on_artists_multi_add_on_id_8c054ca7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_artists_multi_add_on_id_8c054ca7 ON public.ludorecherche_multiaddon_artists USING btree (multiaddon_id);


--
-- Name: ludorecherche_multi_add_on_designers_designer_id_63ada047; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_designers_designer_id_63ada047 ON public.ludorecherche_multiaddon_designers USING btree (designer_id);


--
-- Name: ludorecherche_multi_add_on_designers_multi_add_on_id_5b1af8fc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_designers_multi_add_on_id_5b1af8fc ON public.ludorecherche_multiaddon_designers USING btree (multiaddon_id);


--
-- Name: ludorecherche_multi_add_on_difficulty_id_5c7d95a0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_difficulty_id_5c7d95a0 ON public.ludorecherche_multiaddon USING btree (difficulty_id);


--
-- Name: ludorecherche_multi_add_on_games_game_id_790ba75d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_games_game_id_790ba75d ON public.ludorecherche_multiaddon_games USING btree (game_id);


--
-- Name: ludorecherche_multi_add_on_games_multi_add_on_id_9f3c31b9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_games_multi_add_on_id_9f3c31b9 ON public.ludorecherche_multiaddon_games USING btree (multiaddon_id);


--
-- Name: ludorecherche_multi_add_on_language_id_5be310e3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_language_id_5be310e3 ON public.ludorecherche_multiaddon USING btree (language_id);


--
-- Name: ludorecherche_multi_add_on_multi_add_on_id_25357591; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_multi_add_on_id_25357591 ON public.ludorecherche_multiaddon_playing_mode USING btree (multiaddon_id);


--
-- Name: ludorecherche_multi_add_on_name_7a883fb9_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_name_7a883fb9_like ON public.ludorecherche_multiaddon USING btree (name varchar_pattern_ops);


--
-- Name: ludorecherche_multi_add_on_playing_mode_playingmode_id_3de7a256; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_playing_mode_playingmode_id_3de7a256 ON public.ludorecherche_multiaddon_playing_mode USING btree (playingmode_id);


--
-- Name: ludorecherche_multi_add_on_publishers_multi_add_on_id_22811669; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_publishers_multi_add_on_id_22811669 ON public.ludorecherche_multiaddon_publishers USING btree (multiaddon_id);


--
-- Name: ludorecherche_multi_add_on_publishers_publisher_id_ca696d8c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_multi_add_on_publishers_publisher_id_ca696d8c ON public.ludorecherche_multiaddon_publishers USING btree (publisher_id);


--
-- Name: ludorecherche_playingmode_name_b9bc9f89_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_playingmode_name_b9bc9f89_like ON public.ludorecherche_playingmode USING btree (name varchar_pattern_ops);


--
-- Name: ludorecherche_publisher_name_865b1ff3_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_publisher_name_865b1ff3_like ON public.ludorecherche_publisher USING btree (name varchar_pattern_ops);


--
-- Name: ludorecherche_tag_name_de380dee_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ludorecherche_tag_name_de380dee_like ON public.ludorecherche_tag USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon_artists ludorecherche_add_on_artist_id_947142f9_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_artists
    ADD CONSTRAINT ludorecherche_add_on_artist_id_947142f9_fk_ludoreche FOREIGN KEY (artist_id) REFERENCES public.ludorecherche_artist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon_designers ludorecherche_add_on_designer_id_c16eab7d_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_designers
    ADD CONSTRAINT ludorecherche_add_on_designer_id_c16eab7d_fk_ludoreche FOREIGN KEY (designer_id) REFERENCES public.ludorecherche_designer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon ludorecherche_add_on_difficulty_id_36e9a090_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon
    ADD CONSTRAINT ludorecherche_add_on_difficulty_id_36e9a090_fk_ludoreche FOREIGN KEY (difficulty_id) REFERENCES public.ludorecherche_difficulty(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon ludorecherche_add_on_game_id_fc9844ac_fk_ludorecherche_game_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon
    ADD CONSTRAINT ludorecherche_add_on_game_id_fc9844ac_fk_ludorecherche_game_id FOREIGN KEY (game_id) REFERENCES public.ludorecherche_game(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon ludorecherche_add_on_language_id_5573aafd_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon
    ADD CONSTRAINT ludorecherche_add_on_language_id_5573aafd_fk_ludoreche FOREIGN KEY (language_id) REFERENCES public.ludorecherche_language(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon_playing_mode ludorecherche_add_on_playingmode_id_12919a41_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_playing_mode
    ADD CONSTRAINT ludorecherche_add_on_playingmode_id_12919a41_fk_ludoreche FOREIGN KEY (playingmode_id) REFERENCES public.ludorecherche_playingmode(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon_publishers ludorecherche_add_on_publisher_id_14abff3e_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_publishers
    ADD CONSTRAINT ludorecherche_add_on_publisher_id_14abff3e_fk_ludoreche FOREIGN KEY (publisher_id) REFERENCES public.ludorecherche_publisher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon_publishers ludorecherche_addon__addon_id_336553d8_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_publishers
    ADD CONSTRAINT ludorecherche_addon__addon_id_336553d8_fk_ludoreche FOREIGN KEY (addon_id) REFERENCES public.ludorecherche_addon(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon_playing_mode ludorecherche_addon__addon_id_448e903f_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_playing_mode
    ADD CONSTRAINT ludorecherche_addon__addon_id_448e903f_fk_ludoreche FOREIGN KEY (addon_id) REFERENCES public.ludorecherche_addon(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon_artists ludorecherche_addon__addon_id_dcf26241_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_artists
    ADD CONSTRAINT ludorecherche_addon__addon_id_dcf26241_fk_ludoreche FOREIGN KEY (addon_id) REFERENCES public.ludorecherche_addon(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_addon_designers ludorecherche_addon__addon_id_ea0e0c5c_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_addon_designers
    ADD CONSTRAINT ludorecherche_addon__addon_id_ea0e0c5c_fk_ludoreche FOREIGN KEY (addon_id) REFERENCES public.ludorecherche_addon(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game_artists ludorecherche_game_a_artist_id_3e5506bf_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_artists
    ADD CONSTRAINT ludorecherche_game_a_artist_id_3e5506bf_fk_ludoreche FOREIGN KEY (artist_id) REFERENCES public.ludorecherche_artist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game_artists ludorecherche_game_a_game_id_2ba0fcde_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_artists
    ADD CONSTRAINT ludorecherche_game_a_game_id_2ba0fcde_fk_ludoreche FOREIGN KEY (game_id) REFERENCES public.ludorecherche_game(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game_designers ludorecherche_game_d_designer_id_8b4d087f_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_designers
    ADD CONSTRAINT ludorecherche_game_d_designer_id_8b4d087f_fk_ludoreche FOREIGN KEY (designer_id) REFERENCES public.ludorecherche_designer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game_designers ludorecherche_game_d_game_id_6d1526cc_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_designers
    ADD CONSTRAINT ludorecherche_game_d_game_id_6d1526cc_fk_ludoreche FOREIGN KEY (game_id) REFERENCES public.ludorecherche_game(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game ludorecherche_game_difficulty_id_c4f6b87a_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game
    ADD CONSTRAINT ludorecherche_game_difficulty_id_c4f6b87a_fk_ludoreche FOREIGN KEY (difficulty_id) REFERENCES public.ludorecherche_difficulty(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game ludorecherche_game_language_id_38e7eecd_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game
    ADD CONSTRAINT ludorecherche_game_language_id_38e7eecd_fk_ludoreche FOREIGN KEY (language_id) REFERENCES public.ludorecherche_language(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game_playing_mode ludorecherche_game_p_game_id_62bd95b2_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_playing_mode
    ADD CONSTRAINT ludorecherche_game_p_game_id_62bd95b2_fk_ludoreche FOREIGN KEY (game_id) REFERENCES public.ludorecherche_game(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game_publishers ludorecherche_game_p_game_id_a425abf8_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_publishers
    ADD CONSTRAINT ludorecherche_game_p_game_id_a425abf8_fk_ludoreche FOREIGN KEY (game_id) REFERENCES public.ludorecherche_game(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game_playing_mode ludorecherche_game_p_playingmode_id_fa02659e_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_playing_mode
    ADD CONSTRAINT ludorecherche_game_p_playingmode_id_fa02659e_fk_ludoreche FOREIGN KEY (playingmode_id) REFERENCES public.ludorecherche_playingmode(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game_publishers ludorecherche_game_p_publisher_id_5176fa38_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_publishers
    ADD CONSTRAINT ludorecherche_game_p_publisher_id_5176fa38_fk_ludoreche FOREIGN KEY (publisher_id) REFERENCES public.ludorecherche_publisher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game_tag ludorecherche_game_t_game_id_065ca217_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_tag
    ADD CONSTRAINT ludorecherche_game_t_game_id_065ca217_fk_ludoreche FOREIGN KEY (game_id) REFERENCES public.ludorecherche_game(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_game_tag ludorecherche_game_tag_tag_id_d515082c_fk_ludorecherche_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_game_tag
    ADD CONSTRAINT ludorecherche_game_tag_tag_id_d515082c_fk_ludorecherche_tag_id FOREIGN KEY (tag_id) REFERENCES public.ludorecherche_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon_artists ludorecherche_multi__artist_id_b04b65bc_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_artists
    ADD CONSTRAINT ludorecherche_multi__artist_id_b04b65bc_fk_ludoreche FOREIGN KEY (artist_id) REFERENCES public.ludorecherche_artist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon_designers ludorecherche_multi__designer_id_63ada047_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_designers
    ADD CONSTRAINT ludorecherche_multi__designer_id_63ada047_fk_ludoreche FOREIGN KEY (designer_id) REFERENCES public.ludorecherche_designer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon ludorecherche_multi__difficulty_id_5c7d95a0_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon
    ADD CONSTRAINT ludorecherche_multi__difficulty_id_5c7d95a0_fk_ludoreche FOREIGN KEY (difficulty_id) REFERENCES public.ludorecherche_difficulty(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon_games ludorecherche_multi__game_id_790ba75d_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_games
    ADD CONSTRAINT ludorecherche_multi__game_id_790ba75d_fk_ludoreche FOREIGN KEY (game_id) REFERENCES public.ludorecherche_game(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon ludorecherche_multi__language_id_5be310e3_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon
    ADD CONSTRAINT ludorecherche_multi__language_id_5be310e3_fk_ludoreche FOREIGN KEY (language_id) REFERENCES public.ludorecherche_language(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon_playing_mode ludorecherche_multi__playingmode_id_3de7a256_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_playing_mode
    ADD CONSTRAINT ludorecherche_multi__playingmode_id_3de7a256_fk_ludoreche FOREIGN KEY (playingmode_id) REFERENCES public.ludorecherche_playingmode(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon_publishers ludorecherche_multi__publisher_id_ca696d8c_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_publishers
    ADD CONSTRAINT ludorecherche_multi__publisher_id_ca696d8c_fk_ludoreche FOREIGN KEY (publisher_id) REFERENCES public.ludorecherche_publisher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon_playing_mode ludorecherche_multia_multiaddon_id_02284858_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_playing_mode
    ADD CONSTRAINT ludorecherche_multia_multiaddon_id_02284858_fk_ludoreche FOREIGN KEY (multiaddon_id) REFERENCES public.ludorecherche_multiaddon(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon_publishers ludorecherche_multia_multiaddon_id_55fa2c01_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_publishers
    ADD CONSTRAINT ludorecherche_multia_multiaddon_id_55fa2c01_fk_ludoreche FOREIGN KEY (multiaddon_id) REFERENCES public.ludorecherche_multiaddon(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon_games ludorecherche_multia_multiaddon_id_6c77264c_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_games
    ADD CONSTRAINT ludorecherche_multia_multiaddon_id_6c77264c_fk_ludoreche FOREIGN KEY (multiaddon_id) REFERENCES public.ludorecherche_multiaddon(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon_artists ludorecherche_multia_multiaddon_id_9786d6b9_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_artists
    ADD CONSTRAINT ludorecherche_multia_multiaddon_id_9786d6b9_fk_ludoreche FOREIGN KEY (multiaddon_id) REFERENCES public.ludorecherche_multiaddon(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ludorecherche_multiaddon_designers ludorecherche_multia_multiaddon_id_f9dc6804_fk_ludoreche; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ludorecherche_multiaddon_designers
    ADD CONSTRAINT ludorecherche_multia_multiaddon_id_f9dc6804_fk_ludoreche FOREIGN KEY (multiaddon_id) REFERENCES public.ludorecherche_multiaddon(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

